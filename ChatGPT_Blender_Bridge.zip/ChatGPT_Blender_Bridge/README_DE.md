# ChatGPT Blender Bridge 1.1.0 — lokaler MCP-Zugriff für Blender

Das Paket verbindet einen unterstützten lokalen ChatGPT-Desktop-/Work- oder Codex-Plugin-Host über MCP mit Blender. Ziel ist **Blender 5.2.2 LTS** (Stand 12. Oktober 2026); das Blender-Add-on deklariert eine Mindestversion von 4.2.0. Die Implementierung verwendet Blender-Python und die Python-Standardbibliothek. Sie benötigt keine Plugin-eigene kostenpflichtige Lizenz und enthält kein eigenes Nutzungslimit.

> **Wichtig:** Die Plugin-Datei kann installiert werden, aber sie kann Produkt-/Kontogrenzen nicht umgehen. ChatGPT im Browser kann nicht einfach `127.0.0.1` auf deinem PC aufrufen. Für einen unterstützten Remote-ChatGPT-MCP-Zugang ist eine sichere Tunnel-/HTTPS-Verbindung und ein Konto mit passenden MCP-Schreibrechten notwendig. Lokal kann ein unterstützter Desktop-Plugin-Host den stdio-MCP-Server verwenden. Kein externes Netzwerk wird vom Blender-Add-on geöffnet.

## Welche Datei wofür?

- `ChatGPT_Blender_Bridge_Plugin_1.1.0.zip`: Plugin-Archiv mit `.codex-plugin/plugin.json`, MCP-Konfiguration und Skill-Dateien. Es enthält den von dir vermissten Plugin-Manifest-Pfad.
- `ChatGPT_Blender_Bridge_Addon_1.1.0.zip`: Blender-Extension-Archiv mit `blender_manifest.toml` und `__init__.py`.
- Vollpaket: Quellen, Tests, Installer, Anleitung und die zwei ZIP-Dateien.

## Lokale Installation unter Windows

1. Entpacke das Vollpaket in einen normalen Ordner.
2. Führe `install_local_plugin.ps1` mit deinem normalen Benutzerkonto aus (nicht als Administrator). Das Skript legt eine Sicherung an, installiert die Bridge-Dateien nach `%USERPROFILE%\Documents\ChatGPT_Blender_Bridge`, legt einen lokalen Plugin-Marktplatz unter `%USERPROFILE%\.agents\plugins` an bzw. ergänzt ihn und installiert das Blender-Add-on in den höchsten gefundenen Blender-Benutzerprofilordner ab 4.2.
3. Starte Blender neu und aktiviere **ChatGPT Blender Bridge**. Öffne die 3D-Ansicht, drücke `N`, wähle **ChatGPT**, und prüfe, dass `127.0.0.1:9877` als laufend angezeigt wird.
4. Starte die ChatGPT-Desktop-App neu, öffne das Plugin-Verzeichnis/Plugins in Work und installiere **ChatGPT Blender Bridge** aus dem lokalen Marktplatz. Wähle danach einen neuen Chat und bitte das Plugin `get_status` aufzurufen.
5. Falls die Plugin-Oberfläche den lokalen Marktplatz nicht automatisch erkennt, öffne das Plugin-Verzeichnis nach einem vollständigen Neustart erneut; die Marketplace-Datei liegt bei `%USERPROFILE%\.agents\plugins\marketplace.json`.

Alternativ: In Blender > Preferences > Extensions > **Install from Disk** die Datei `ChatGPT_Blender_Bridge_Addon_1.1.0.zip` auswählen und danach aktivieren.

## Funktionsumfang

19 MCP-Tools: Status, Szenenübersicht, Objektliste/-inspektion, primitive Objekte, Kamera, Licht, Transformationsänderung, Duplizieren/Löschen, Materialien, Materialzuweisung, Frames/Keyframes, Szenenvalidierung/Reparatur, Vorschau-Render, `.blend`-Projektkopie und optional Python-Ausführung.

`execute_python` ist **standardmäßig deaktiviert**. Zum Aktivieren muss die Einstellung ausdrücklich in den Add-on-Präferenzen eingeschaltet werden; jeder Aufruf erfordert weiterhin die Freigabe im Blender-Tab. Beliebiger Python-Code läuft mit den vollen Rechten des Blender-Prozesses und ist keine Sandbox. Das Protokoll kann Tool-Argumente und Python-Code enthalten; es lässt sich in den Add-on-Präferenzen abschalten.

Löschvorgänge, Rendern, Speichern einer Projektkopie und Python-Ausführung verlangen standardmäßig eine lokale Freigabe. Dateien werden nur im konfigurierten Projektordner abgelegt; vorhandene Ziel-Dateien werden nicht überschrieben. Vor großen Eingriffen solltest du die `.blend`-Datei selbst sichern.

## Lokale Codex-Konfiguration

Der Installer ergänzt außerdem bei Bedarf `%USERPROFILE%\.codex\config.toml` um den lokalen stdio-MCP-Eintrag. Die Datei wird vor Änderungen zeitgestempelt gesichert. Bestehende MCP-Einträge werden nicht entfernt.

## Remote-ChatGPT-HTTP-Verbindung

Für ChatGPT-Oberflächen, die nur Remote-MCP annehmen, reicht der lokale stdio-Eintrag nicht aus. Das optionale `mcp_server/mcp_http_server.py` stellt `http://127.0.0.1:8765/mcp` mit Bearer-Token bereit. Es bleibt absichtlich auf Loopback gebunden. Verwende für den Remote-Zugang ausschließlich den von ChatGPT unterstützten **Secure MCP Tunnel** oder einen gleichwertig abgesicherten TLS-Tunnel; nie Router-Portweiterleitung und nie einen ungeschützten öffentlichen Port. Der Endpunkt erfordert den Bearer-Token, der bei Verbindungsaufbau als API-Key/Bearer-Zugangsdaten gespeichert werden muss. Das Blender-Add-on selbst bleibt lokal auf Port 9877.

## Teststatus

Durchgeführt in der Paket-Erstellungsumgebung: Python-Syntaxkompilierung, MCP-stdio-Protokolltests, Plugin-Archiv-/Manifest-Prüfung und HTTP-Authentifizierungs-/Initialize-/Toollisten-Smoke-Tests. **Nicht durchgeführt:** kein Live-Aufruf gegen deine echte Blender-Instanz, kein echtes ChatGPT-Konto-End-to-End und kein echter Render-/Speichertest innerhalb Blender. Daher wird die Verbindung nicht als vollständig end-to-end getestet oder garantiert bezeichnet.
